# Scraper Shopify com Playwright

API pronta para rodar na Vercel.

## Como usar:

Acesse a rota:

```
/api/scrape?url=https://sualoja.com/produto/xyz
```

Retorna JSON com título, preço, imagem e descrição.
